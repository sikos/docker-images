#!/bin/bash

docker build -f Dockerfile.jkd11.slim -t openjdk:11-jdk-alpine .
docker build -f  Dockerfile.jkd8.slim -t openjdk:8-jdk-alpine .
docker build -f  Dockerfile.jkd8.slim -t localhost:jdk8-mvn-alpine .
docker build -f Dockerfile.jkd11.slim -t localhost:jdk11-mvn-alpine .
